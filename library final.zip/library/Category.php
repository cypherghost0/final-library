<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Category | Library</title>
</head>
<body>
    <?php include('navbar.php');?>
    <div class="body-content">
        <div class="left-cont">
            <div class="septs">
                <form method="POST" action="./include/Room.inc.php" class="books">
                    <div class="form-head">
                        <h2>Class Reg:</h2>
                    </div>
                    <div class="ins">
                        <input type="text" placeholder="Add Class" name="rooms" required>
                    </div>
                    <button type="submit" class="btn btn-success" name="add_class"><i class="fa-solid fa-plus fa-lg"></i> Add Class</button>
                    <?php include('errorDisplay.php');?>
                </form>
            </div>
            <div class="septs">
                <form method="POST" action="./include/Category.inc.php" class="books">
                    <div class="form-head">
                        <h2>Book Category</h2>
                    </div>
                    <div class="ins">
                        <input type="text" placeholder="Book Category" name="category" required>
                    </div>
                    <button type="submit" class="btn btn-success" name="add_category"><i class="fa-solid fa-plus fa-lg"></i> Add Category</button>
                    <?php include('errorDisplay.php');?>
                </form>
            </div>
        </div>
        <div class="teble-holder">
            <div class="right-table">
                <div class="content-header">
                    <h2>Rooms</h2>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr id="header">
                                <th>No.</th>
                                <th>room</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="mydata">
                        <?php
                                $No = null;
                                include('./classes/module.class.php');
                                $fetch = new roomFetch();
                                $result = $fetch->fetchData();
                                foreach($result as $data){
                            ?>
                            <tr>
                                <td><?=++$No;?></td>
                                <td><?=$data['room_name'];?></td>
                                <td><a href="./include/delete.inc.php?room_id=<?=$data['room_id'];?>"><i class="fa-solid fa-trash-arrow-up fa-xl"></i></a></td>
                            </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                    
                </div>
            </div><br>
            <div class="left-table">
                <div class="content-header">
                    <h2>Books Category</h2>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr id="header">
                                <th>No.</th>
                                <th>Book Category</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="my-data">
                            <?php
                                $No = null;
                                $fetch = new categoryFetch();
                                $result = $fetch->fetchData();
                                foreach($result as $data){
                            ?>
                            <tr>
                                <td><?=++$No;?></td>
                                <td><?=$data['category_name'];?></td>
                                <td><a href="./include/delete.inc.php?category_id=<?=$data['id'];?>"><i class="fa-solid fa-trash-arrow-up fa-xl"></i></a></td>
                            </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
    <?php include('footer.php');?>
</body>
</html>