<?php

if(isset($_POST["add_borrow"]))
{
    $scid = $_POST['scid'];
    $isbn = $_POST['isbn']; 

    include "../classes/module.class.php";

    $borrow = new borrowSetUp($scid,$isbn);
    $borrow->setUp();
    // header("location: ../index.php?error=none");
}