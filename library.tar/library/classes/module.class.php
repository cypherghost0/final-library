<?php

class Db
{
    protected function connect()
    {
        try {
            $username = "root";
            $password = "";
            $db = mysqli_connect("localhost", "root", "", "library");
            return $db;
        } catch (Exception $e) {
            print "Error: " . $e->getMessage() . "<br/>";
            die();
        }
    }
}

// class Db
// {
//     protected function connect()
//     {
//         try {
//             $username = "if0_35338984";
//             $password = "g8A5f1bnTtHQYn";
//             $db = mysqli_connect("sql213.infinityfree.com", "if0_35338984", "g8A5f1bnTtHQYn", "if0_35338984_library");
//             return $db;
//         } catch (Exception $e) {
//             print "Error: " . $e->getMessage() . "<br/>";
//             die();
//         }
//     }
// }
class mainController extends Db
{
    private $username;
    private $email;
    private $pass_1;
    private $pass_2;

    public function __construct($username, $email, $pass_1, $pass_2)
    {
        $this->username = $username;
        $this->email = $email;
        $this->pass_1 = $pass_1;
        $this->pass_2 = $pass_2;
    }

    public function setUser($username, $password, $email)
    {
        $hash_password = password_hash($password, PASSWORD_DEFAULT);
        $token = rand(0, 100000) . "@" . date('Y');
        $stmt = mysqli_query($this->connect(), "INSERT INTO `user`(`username`, `email`, `password`,`Token`) VALUES ('$username','$email','$hash_password','$token')");
        if ($stmt) {
            $stmt = null;
            echo "user created";
            header("location: ../index.php");
            exit();
        }
        $stmt = null;
    }

    public function checkUser($username, $email)
    {
        $query = "SELECT `username`, `email` FROM `user` WHERE username = '$username' OR email = '$email'";
        $stmt = mysqli_query($this->connect(), $query);
        $resultCheck = null;
        if (mysqli_num_rows($stmt) > 0) {
            $resultCheck = false;
        } else {
            $this->setUser($this->username, $this->pass_1, $this->email);
        }
        return $resultCheck;
    }

    public function signupUser()
    {
        if ($this->emptyInput() == false) {
            header("location: ../registration.php?error=emptyinput");
            exit();
        }
        if ($this->invalidUsername() == false) {
            header("location: ../registration.php?error=Username");
            exit();
        }
        if ($this->invalidEmail() == false) {
            header("location: ../registration.php?error=email");
            exit();
        }
        if ($this->pwdMatch() == false) {
            header("location: ../registration.php?error=pwdMatch");
            exit();
        }
        if ($this->uidTakenCheck() == false) {
            header("location: ../registration.php?error=uidTakenCheck");
            exit();
        }
        // if($this->checkUser() == false){
        //     header("location: ../registration.php?error=userExists");
        //     exit();
        // }

    }

    private function emptyInput()
    {
        $result = null;
        if (empty($this->username) || empty($this->email) || empty($this->pass_1) || empty($this->pass_2)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    private function invalidUsername()
    {
        $result = null;
        if (!preg_match("/^[a-zA-Z0-9]*$/", $this->username)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    private function invalidEmail()
    {
        $result = null;
        if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    private function pwdMatch()
    {
        $result = null;
        if ($this->pass_1 !== $this->pass_2) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }

    private function uidTakenCheck()
    {
        $result = null;
        if (!$this->checkUser($this->username, $this->email)) {
            $result = false;
        } else {
            $result = true;
        }
        return $result;
    }
}

class loginController extends Db
{
    private $username;
    private $password;

    public function __construct($username, $password)
    {
        $this->username = $username;
        $this->password = $password;
        session_start();
    }

    public function loginUser()
    {

        $holder = $column = "";
        if (filter_var($this->username, FILTER_VALIDATE_EMAIL)) {
            $holder = "email = '" . $this->username . "'";
        } else {
            $holder = "username = '" . $this->username . "'";
        }
        $query = "SELECT * FROM user WHERE " . $holder;
        $stmt = mysqli_query($this->connect(), $query);
        $fetch_data = mysqli_fetch_assoc($stmt);
        $pwd_verify = password_verify($this->password, $fetch_data['password']);

        if ($pwd_verify) {
            $_SESSION['uid'] = $fetch_data['Token'];
            header('location: ../Dashboard.php');
        } else {
            header('location: ../index.php?error=Incorrect');
        }
    }
}

class categorySetUp extends Db
{
    private $category;

    public function __construct($category)
    {
        $this->category = $category;
        session_start();
    }

    public function setUp()
    {
        $query = "INSERT INTO Category(category_name) VALUES ('$this->category')";
        $execute = mysqli_query($this->connect(), $query);
        if ($execute) {
            header('location: ../Category.php');
        }
    }
}

class categoryFetch extends Db
{
    public function fetchData()
    {
        $query = "SELECT * FROM Category";
        $execute = mysqli_query($this->connect(), $query);
        return $execute;
    }
}

class categoryDestroy extends Db
{
    private $category_id;

    public function __construct($category_id)
    {
        $this->category_id = $category_id;
    }

    public function deleteData()
    {
        $query = "DELETE FROM `Category` WHERE id = " . $this->category_id;
        $execute = mysqli_query($this->connect(), $query);
        if ($query) {
            return true;
        }
    }
}


// rooms addition
class classSetUp extends Db
{
    private $room;

    public function __construct($room)
    {
        $this->room = $room;
        session_start();
    }

    public function setUp()
    {
        $query = "INSERT INTO room(room_name) VALUES ('$this->room')";
        $execute = mysqli_query($this->connect(), $query);
        if ($execute) {
            header('location: ../Category.php');
        }
    }
}

class roomFetch extends Db
{
    public function fetchData()
    {
        $query = "SELECT * FROM room";
        $execute = mysqli_query($this->connect(), $query);
        return $execute;
    }
}

class roomDestroy extends Db
{
    private $room_id;

    public function __construct($room_id)
    {
        $this->room_id = $room_id;
    }

    public function deleteData()
    {
        $query = "DELETE FROM `room` WHERE room_id=" . $this->room_id;
        $execute = mysqli_query($this->connect(), $query);
        if ($query) {
            return true;
        }
    }
}

// book delete 
class bookDistroy extends Db
{
    private $books_isbn;
    private $books_id;

    public function __construct($books_id)
    {
        $this->books_id = $books_id;
    }

    public function deleteData()
    {
        $query = "DELETE FROM `book` WHERE isbn= " . $this->books_id;
        $execute = mysqli_query($this->connect(), $query);
        if ($query) {
            return true;
        }
    }
}
class bookSetUp extends Db
{
    private $isbn;
    private $title;
    private $author;
    private $copy;
    private $category;

    public function __construct($isbn, $title, $author, $copy, $category)
    {
        $this->isbn = $isbn;
        $this->title = $title;
        $this->author = $author;
        $this->copy = $copy;
        $this->category = $category;
    }

    public function setUp()
    {
        $num = 1;
        if ($this->copy > $num) {
            while ($num <= $this->copy) {
                $isbn = $this->isbn . "." . $num;
                $query = "INSERT INTO book(`isbn`,`title`,`author`,`copy`,`category`,`status`) VALUES ('$isbn','$this->title','$this->author','$this->copy','$this->category','NULL')";
                $execute = mysqli_query($this->connect(), $query);
                $num++;
            }
            if($execute ==true){
                header("location: ../Dashboard.php");
            }
        } else {
            $query = "INSERT INTO book(`isbn`,`title`,`author`,`copy`,`category`,`status`) VALUES ('$this->isbn','$this->title','$this->author','$this->copy','$this->category','NULL')";
            $execute = mysqli_query($this->connect(), $query);
            if($execute == true){
                header("location: ../Dashboard.php");
            }
        }
    }
}

class bookFetch extends Db
{
    public function fetchData()
    {
        $query = "SELECT * FROM book INNER JOIN Category ON book.category=Category.id WHERE `status` = 'NULL'";
        $execute = mysqli_query($this->connect(), $query);
        return $execute ;
    }
}

class bookDestroy extends Db
{
    private $book_id;
    private $category_id;

    public function __construct($book_id)
    {
        $this->category_id = $book_id;
    }

    public function deleteData()
    {
        $query = "DELETE FROM `book` WHERE id = " . $this->category_id;
        $execute = mysqli_query($this->connect(), $query);
        if ($query) {
            return true;
        }
    }
}

class counterFetch extends Db
{
    public function bookData()
    {
        $query = "SELECT * FROM book,Category where book.category = Category.id AND `status` = 'NULL'";
        $execute = mysqli_query($this->connect(), $query);
        $count_no = 0;
        foreach ($execute as $count) {
            $count_no++;
        }
        return $count_no;
    }

    public function allBookData()
    {
        $query = "SELECT * FROM book";
        $execute = mysqli_query($this->connect(), $query);
        $count_no = 0;
        foreach ($execute as $count) {
            $count_no++;
        }
        return $count_no;
    }

    public function borrowData()
    {
        $query = "SELECT * FROM borrow";
        $execute = mysqli_query($this->connect(), $query);
        $count_no = 0;
        foreach ($execute as $count) {
            $count_no++;
        }
        return $count_no;
    }

    public function issueData()
    {
        $query = "SELECT * FROM issue";
        $execute = mysqli_query($this->connect(), $query);
        $count_no = 0;
        foreach ($execute as $count) {
            $count_no++;
        }
        return $count_no;
    }
}

class studentSetUp extends Db
{
    private $scid;
    private $fname;
    private $lname;
    private $stu_room;

    public function __construct($scid, $fname, $lname,$student_room)
    {
        $this->scid = $scid;
        $this->fname = $fname;
        $this->lname = $lname;
        $this->stu_room = $student_room;
    }

    public function setUp()
    {
        $query = "INSERT INTO student(`scid`,`fname`,`lname`,`student_room`) VALUES ('$this->scid','$this->fname','$this->lname','$this->stu_room')";
        $execute = mysqli_query($this->connect(), $query);
        header('location: ../Student.php');
    }
}

class studentFetch extends Db
{
    public function fetchData()
    {
        $query = "SELECT * FROM student";
        // $query = "SELECT * FROM student INNER JOIN room ON room.student=student.room_id WHERE 1";
        $execute = mysqli_query($this->connect(), $query);
        return $execute;
    }
}

class studentDestroy extends Db
{
    private $student_id;

    public function __construct($student_id)
    {
        $this->student_id = $student_id;
    }

    public function deleteData()
    {
        $query = "DELETE FROM `student` WHERE id = " . $this->student_id;
        $execute = mysqli_query($this->connect(), $query);
        if ($query) {
            return true;
        }
    }
}

class borrowSetUp extends Db
{
    private $scid;
    private $isbn;

    public function __construct($scid, $isbn)
    {
        $this->scid = $scid;
        $this->isbn = $isbn;
    }

    public function setUp()
    {
        $result1 = null;
        $result2 = null;
        $result3 = null;
        $query = "SELECT * FROM book WHERE `isbn` = '$this->isbn'";
        $execute1 = mysqli_query($this->connect(), $query);

        if (mysqli_num_rows($execute1) == 0) {
            $result1 = false;
        }
        $query = "SELECT * FROM student WHERE `scid` = '$this->scid'";
        $execute2 = mysqli_query($this->connect(), $query);

        if (mysqli_num_rows($execute2) == 0) {
            $result1 = false;
        }

        $query = "SELECT * FROM book WHERE `status` = 'Borrowed' AND `isbn` = '$this->isbn'";
        $execute5 = mysqli_query($this->connect(), $query);

        if (mysqli_num_rows($execute5) == 1) {
            $result3 = true;
        }

        if ($result1 !== false && $result2 !== false && $result3 !== true) {
            $query = "INSERT INTO borrow(`scid`,`isbn`) VALUES ('$this->scid','$this->isbn')";
            $execute3 = mysqli_query($this->connect(), $query);
            if ($execute3) {
                $query = "UPDATE `book` SET `status`='Borrowed' WHERE `isbn` = '$this->isbn'";
                $execute4 = mysqli_query($this->connect(), $query);
                header('location: ../Borrow.php');
            }
        } else {
            header('location: ../Borrow.php?error=booksciderror');
        }

        if ($result3 == true) {
            header('location: ../Borrow.php?error=bookborrowed');
        }
    }
}

class borrowFetch extends Db
{
    public function fetchData()
    {
        $query = "SELECT * FROM borrow,book,student WHERE book.isbn = borrow.isbn AND student.scid = borrow.scid";
        $execute = mysqli_query($this->connect(), $query);
        return $execute;
    }
}

class borrowDestroy extends Db
{
    private $borrow_id;

    public function __construct($borrow_id)
    {
        $this->borrow_id = $borrow_id;
    }

    public function deleteData()
    {
        $query = "DELETE FROM `borrow` WHERE isbn = " . $this->borrow_id;
        $execute = mysqli_query($this->connect(), $query);

        $query1 = "UPDATE `book` SET `status`='NULL' WHERE `isbn`='" . $this->borrow_id . "'";
        $execute1 = mysqli_query($this->connect(), $query1);
        return true;
    }
}

class issueSetUp extends Db
{
    private $message;
    private $isbn;

    public function __construct($isbn, $message)
    {
        $this->isbn = $isbn;
        $this->message = $message;
    }

    public function setUp()
    {

        $query = "INSERT INTO issue(`isbn`,`issue_comment`) VALUES ('$this->isbn','$this->message')";
        $execute3 = mysqli_query($this->connect(), $query);
        if ($execute3) {
            $query = "UPDATE `book` SET `status`='Issued' WHERE `isbn` = '$this->isbn'";
            $execute4 = mysqli_query($this->connect(), $query);
            header('location: ../Issued.php');
        }
    }
}

class issueFetch extends Db
{
    public function fetchData()
    {
        $query = "SELECT * FROM issue,book WHERE book.isbn = issue.isbn";
        $execute = mysqli_query($this->connect(), $query);
        return $execute;
    }
}

class issueDestroy extends Db
{
    private $issue_id;

    public function __construct($issue_id)
    {
        $this->issue_id = $issue_id;
    }

    public function deleteData()
    {
        $query = "DELETE FROM `issue` WHERE isbn = " . $this->issue_id;
        $execute = mysqli_query($this->connect(), $query);

        $query1 = "UPDATE `book` SET `status`='NULL' WHERE `isbn`='" . $this->issue_id . "'";
        $execute1 = mysqli_query($this->connect(), $query1);
        return true;
    }
}

class exportData extends Db
{
    public function Borrow()
    {

        $query = new borrowFetch;
        $data = $query->fetchData();
        $n = 0;
        foreach ($data as $list) {
            $record = "
            <tr>
            <td>" . ++$n . "</td>
            <td>" . $list['Date_registered'] . "</td>
            <td>" . $list['fname'] . " " . $list['lname'] . "</td>
            <td>" . $list['title'] . "</td>
            <td>" . $list['isbn'] . "</td>
        </tr>
            ";
        }
        $table = '
        <div class="head-content">
            <div>
                <h2 style="text-align: center;">LIBRARY MANAGEMENT BORROW REPORT</h2>
                <h3 style="width: 400px;text-align: center;">STUDENT LIST</h3>
            </div>
            <table border="1">
                <thead style="background-image: linear-gradient(50deg, rgb(160, 102, 214),rgb(77, 51, 170)); color: white;border-radius: 10px;">
                    <tr>
                        <th style="width: 30px;">No</th>
                        <th style="width: 200px;">date</th>
                        <th style="50px;">Student Name</th>
                        <th style="50px;">Book Name</th>
                        <th style="width: 100px;">ISBN No.</th>
                        
                        
                    </tr>
                </thead>
                <tbody>
                ' . $record . '
                </tbody>
            </table>
        </div>
        ';
        header('Content-Type: application/force-download');
        header('Content-Disposition: attachment; filename=Report.xls');
        header('Content-Transfer-Encoding: BINARY');
        print($table);
    }
    public function Issue()
    {

        $query = new issueFetch;
        $data = $query->fetchData();
        $n = 0;
        foreach ($data as $list) {
            $record = "
            <tr>
            <td>" . ++$n . "</td>
            <td>" . $list['date_record'] . "</td>
            <td>" . $list['isbn'] . "</td>
            <td>" . $list['title'] . "</td>
            <td>" . $list['issue_comment'] . "</td>
        </tr>
            ";
        }
        $table = '
        <div class="head-content">
            <div>
                <h2 style="text-align: center;">LIBRARY MANAGEMENT ISSUED REPORT</h2>
                <h3 style="width: 400px;text-align: center;">STUDENT LIST</h3>
            </div>
            <table border="1">
                <thead style="background-image: linear-gradient(50deg, rgb(160, 102, 214),rgb(77, 51, 170)); color: white;border-radius: 10px;">
                    <tr>
                        <th style="width: 30px;">No</th>
                        <th style="width: 200px;">Date And Time</th>
                        <th style="width: 100px;">ISBN No.</th>
                        <th style="50px;">Book Name</th>
                        <th style="50px;">Reason</th>
                    </tr>
                </thead>
                <tbody>
                ' . $record . '
                </tbody>
            </table>
        </div>
        ';
        header('Content-Type: application/force-download');
        header('Content-Disposition: attachment; filename=Report.xls');
        header('Content-Transfer-Encoding: BINARY');
        print($table);
    }
}
