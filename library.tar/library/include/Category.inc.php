<?php

if(isset($_POST["add_category"]))
{
    $category = $_POST['category'];

    include "../classes/module.class.php";

    $category = new categorySetUp($category);
    $category->setUp();
    // header("location: ../index.php?error=none");
}