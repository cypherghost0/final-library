<?php

if(isset($_POST["add_class"]))
{
    $room = $_POST['rooms'];

    include "../classes/module.class.php";

    $room = new classSetUp($room);
    $room->setUp();
    // header("location: ../index.php?error=none");
}