<?php include('include/trigger.php');?>
<nav>
    <div class="logo">
        <div class="logo-img">
            <img src="./img/logo.JPG" alt="logo" srcset=""><br>
        </div>
        <span> BTR RWAMIKO TSS LMS</span>
    </div>
    <div class="links">
        <a href="./Dashboard.php">Home</a>
        <a href="./Category.php"><i class="fa-solid fa-book-bookmark"></i> Category</a>
        <a href="./Student.php"><i class="fa-solid fa-graduation-cap"></i> Student</a>
        <a href="./Borrow.php"><i class="fa-solid fa-hand-holding fa-lg"></i> Borrow</a>
        
        <a href="./Issued.php"> <i class="fa-solid fa-circle-exclamation"></i> Issue Book</a>
        <div class="logout">
            <a href="include/logout.inc.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> logout</a>
        </div>
    </div>
</nav>