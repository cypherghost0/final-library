<?php

if(isset($_POST["add_issue"]))
{
    $isbn = $_POST['isbn'];
    $message = $_POST['message']; 

    include "../classes/module.class.php";

    $issue = new issueSetUp($isbn,$message);
    $issue->setUp();
    // header("location: ../index.php?error=none");
}