<?php
if (isset($_GET["books_id"])) {
    $bookId = $_GET["books_id"];
    
    // Fetch the book data by its ID
    $fetchBook = new bookFetch();
    $bookData = $fetchBook->fetchBookById($bookId); // You should implement this method

    if ($bookData) {
        // Display the form to edit the book
        ?>
        <form action="./include/update.inc.php" method="POST">
            <input type="hidden" name="book_id" value="<?= $bookData['id']; ?>">
            <label for="isbn">ISBN:</label>
            <input type="text" id="isbn" name="isbn" value="<?= $bookData['isbn']; ?>"><br>

            <label for="title">Book Name:</label>
            <input type="text" id="title" name="title" value="<?= $bookData['title']; ?>"><br>

            <label for="author">Author:</label>
            <input type="text" id="author" name="author" value="<?= $bookData['author']; ?>"><br>

            <label for="category">Category:</label>
            <input type="text" id="category" name="category" value="<?= $bookData['category_name']; ?>"><br>

            <input type="submit" value="Update">
        </form>
        <?php
    } else {
        // Book not found, display an error message or redirect to a 404 page
        echo "Book not found.";
    }
} else {
    // Invalid request, display an error message or redirect to an error page
    echo "Invalid request.";
}
?>
