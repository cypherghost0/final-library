<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Student | Library</title>
</head>
<body>
    <?php include('navbar.php');?>
    <div class="body-content">
        <div class="sept left">
            <form method="POST" action="./include/student.inc.php" class="books">
                <div class="form-head">
                    <h2>Student</h2>
                </div>
                <div class="ins">
                    <input type="text" placeholder="Student Card Id" name="scid">
                </div>
                <div class="ins">
                    <input type="text" placeholder="First Name" name="f_name">
                </div>
                <div class="ins">
                    <input type="text" placeholder="Last Name" name="l_name">
                </div>
                <div class="ins">
                    <select name="stu_room" id="">
                        <option value="">SELECT CLASS</option>
                        <?php
                            include('./classes/module.class.php');
                            $fetch = new roomFetch();
                            $result = $fetch->fetchData();
                            foreach($result as $data){
                        ?>
                        <option value="<?=$data['room_id'];?>"><?=$data['room_name'];?></option>
                        <?php
                            }
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-success" name="add_student"><i class="fa-solid fa-plus fa-lg"></i> Add student</button>
            </form>
        </div>
        <div class="sept right">
            <div class="content-header">
                <h2>Student List</h2>
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                    <tr id="header">
                            <th>No.</th>
                            <th>Student Card</th>
                            <!-- <th>Student Class</th> -->
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody id="my-data">
                        <?php
                            $No = null;
                            $fetch = new studentFetch();
                            $result = $fetch->fetchData();
                            foreach($result as $data){
                        ?>
                        <tr>
                            <td><?=++$No;?></td>
                            <td><?=$data['scid'];?></td>
                            <td><?=$data['fname'];?></td>
                            <td><?=$data['lname'];?></td>
                            <td><a href="./include/delete.inc.php?student_id=<?=$data['id'];?>"> <i class="fa-solid fa-trash-arrow-up fa-xl"></i></a></td>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    <?php include('footer.php');?>
</body>
</html>