<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login | Library</title>
    <style>
      .error{
          background-color: #ff4583;
          color: white;
          padding: 1rem;
          margin-top: 1rem;
          border-radius: .3rem;
      } 
    </style>
</head>
<body>

    <div class="box">
        <form method="POST" class="form" action="include/login.inc.php">
        <h2>BTR RWAMIKO TSS LMS</h2>
        <!-- <h3>Sign In</h3> -->
          <div class="inputbox">
            <input type="text" name="username" required="required">
            <span>Username</span>
            <i></i>
          </div>
          <div class="inputbox">
            <input type="password" name="password" required="required">
            <span>password</span>
            <i></i>
          </div>
          <div class="links">
            <a href="#">Forget Password</a>
            <a href="./registration.php">Sign up</a>
          </div>
          <input type="submit" value="Login" name="loginBtn">  
          <?php require('./errorDisplay.php');?>
        </form>
    </div>
</body>
</html>