<?php

if(isset($_POST["add_book"]))
{
    $isbn = $_POST['isbn'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $copy = $_POST['copy'];
    $category = $_POST['category'];
    include "../classes/module.class.php";

    $category = new bookSetUp($isbn,$title,$author,$copy,$category);
    $category->setUp();
    
}