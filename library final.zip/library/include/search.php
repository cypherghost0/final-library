<?php
$db = mysqli_connect("localhost", "root", "", "library");

if(isset($_GET['btn-search'])){
    $filtervalues =$_GET['search'];
    $query = "SELECT * FROM book WHERE CONCAT(id,isbn,title,author) LIKE '%$filtervalues%' ";
    $query_run = mysqli_query($db,$query);

?>
    <table id="datatablesSimple">
    <thead>
        <tr>
            <th>No</th>
            <th>ISBN</th>
            <th>Book Name</th>
            <th>Author</th>
            <th></th>
        </tr>
    </thead>
    <tbody id="my-data" class="my-data">
            
    <?php if(mysqli_num_rows($query_run)>0){
        foreach($query_run as $items){
            ?>
                <tr>
                    <td><?=$items['id'];?></td>
                    <td><?=$items['isbn'];?></td>
                    <td><?=$items['title'];?></td>
                    <td><?=$items['author'];?></td>
                </tr>
            <?php
        }
    }
} ?>
    </tbody>
</table>
<?php