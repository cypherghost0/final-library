<?php

if(isset($_POST["loginBtn"]))
{
    $username = $_POST['username'];
    $password = $_POST['password'];

    include "../classes/module.class.php";

    $login = new loginController($username,$password);
    $login->loginUser();
    // header("location: ../index.php?error=none");
}