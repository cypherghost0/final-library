<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">
    <title>Sign up | Library</title>
    <style>
      .error{
          background-color: #ff4583;
          color: white;
          padding: 1rem;
          margin-top: 1rem;
          border-radius: .3rem;
      } 
    </style>
</head>
<body>
    <div class="box-up">
        <form class="form" method="POST" action="include/signup.inc.php">
          <h2>Sign up</h2>
          <div class="inputbox">
            <input type="text" name="names" required="required">
            <span>names</span>
            <i></i>
          </div>
          <div class="inputbox">
            <input type="email" name="email" required="required">
            <span>@email.com</span>
            <i></i>
          </div>
          <div class="inputbox">
            <input type="password" name="password" required="required">
            <span>password</span>
            <i></i>
          </div>
          <div class="inputbox">
            <input type="password" name="password2" required="required">
            <span>confirm password</span>
            <i></i>
          </div>
          <div class="links">
            <a href="./index.php">Sign in</a>
          </div>
          <input type="submit" value="Sign up" name="sign_up">  
          <?php require("errorDisplay.php"); ?>
        </form>
    </div>
</body>
</html>