<?php include('include/trigger.php');?>
<footer>
    &copy; CopyRight Reserved @ V&B 2023
</footer>