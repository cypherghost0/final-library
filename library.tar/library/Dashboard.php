<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Book | Library</title>
</head>
<body>
    <?php include('navbar.php');?>
    <div class="body-content">
        <div class="sept left">
            <form method="POST" action="./include/book.inc.php" class="books">
                <div class="form-head">
                    <h2>Book Register</h2>
                </div>
                <div class="ins">
                    <label for="">ISBN No:</label>
                    <input class="input" name="isbn" type="text" placeholder="ISBN No" class="form-control mb-4" autocomplete=off>
                </div>
                <div class="ins">
                    <label for="">book Title:</label>
                    <input class="input" name="title" type="text" placeholder="BOOK NAME" class="form-control mb-4" autocomplete=off>   
                </div>
                <div class="ins">
                    <label for="">book author:</label>
                    <input class="input" name="author" type="text" placeholder="NAME OF AUTHOR" class="form-control mb-4" autocomplete=off><br>
                </div>
                <div class="ins">
                    <label for="">No. of Copy:</label>
                    <input class="input" name="copy" type="text" placeholder="NUMBER OF COPY" class="form-control mb-4" autocomplete=off>
                </div>
                <div class="ins">
                    <label for="">Select category</label>
                    <select name="category" id=""  >
                        <option value="">select level</option>
                        <?php
                            include('./classes/module.class.php');
                            $fetch = new categoryFetch();
                            $result = $fetch->fetchData();
                            foreach($result as $data){
                        ?>
                        <option value="<?=$data['id'];?>"><?=$data['category_name'];?></option>
                        <?php
                            }
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-success" name="add_book"><i class="fa-solid fa-plus"></i>  Add book</button>
            </form>
        </div>
        <?php
            $fetch_counter_Book = new counterFetch();
        ?>
        <div class="sept right">
            <div class="counter-div">
                <div class="counter">
                    <span><?=$fetch_counter_Book->allBookData();?></span>
                    <span>All Books</span>
                </div>
                <div class="counter1">
                    <span><?=$fetch_counter_Book->borrowData();?></span>
                    <span>Borrowed</span>
                </div>
                <div class="counter2">
                    <span><?=$fetch_counter_Book->issueData();?></span>
                    <span>Issued</span>
                </div>
            </div>
            <div class="content-header">
                <h2>Books In Store(<?=$fetch_counter_Book->bookData();?>)</h2>
                <div class="searchBar">
                    <form action="Dashboard.php" method="post">
                    <input type="search" VALUES="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" name="search" placeholder="Search ISBN " autocomplete=off >
                    <button type="submit" name="btn-search" class="custom-button"><i class="fa-solid fa-magnifying-glass fa-xl"></i>Search</button>

                    </form>
                </div>
            </div>

            <div class="card-body">

                <?php
                    // $db = mysqli_connect("sql213.infinityfree.com", "if0_35338984", "g8A5f1bnTtHQYn", "if0_35338984_library");
                    $db = mysqli_connect("localhost", "root", "", "library");
                    if(isset($_POST['btn-search'])){
                        ?>

                        <?php
                        $filtervalues =$_POST['search'];
                        if($filtervalues == ""){
                        ?>

                <table id="datatablesSimple">
                    <thead>
                        <tr id="header">
                            <th>No</th>
                            <th>ISBN</th>
                            <th>Book Name</th>
                            <th>Author</th>
                            <th>Category</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="my-data" class="my-data">

                        <?php
                            // search button
                            $No = null;
                            $fetchBook = new bookFetch();
                            foreach($fetchBook->fetchData() as $data){
                        ?>
                        <tr>
                            <td><?=++$No;?></td>
                            <td><?=$data['isbn'];?></td>
                            <td><?=$data['title'];?></td>
                            <td><?=$data['author'];?></td>
                            <td><?=$data['category_name'];?></td>
                            <td><a href="./include/delete.inc.php?books_id=<?=$data['isbn'];?>"> <i class="fa-solid fa-trash-arrow-up fa-xl"></i> </a></td>

                        </tr>
                    

                        <?php
                            }
                            
                        ?>
                    </tbody>
                </table>


                        
                        <?php
                        }
                        $query = "SELECT * FROM book WHERE CONCAT(id,isbn,title,author) LIKE '%$filtervalues%' AND `status` = 'NULL'";
                        $query_run = mysqli_query($db,$query);

                    ?>
                        <table id="datatablesSimple">
                        <thead>
                        <tr id="header">
                                <th>No</th>
                                <th>ISBN</th>
                                <th>Book Name</th>
                                <th>Author</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="my-data" class="my-data">
                                
                        <?php if(mysqli_num_rows($query_run)>0){
                            foreach($query_run as $items){
                                ?>
                                    <tr>
                                        <td><?=$items['id'];?></td>
                                        <td><?=$items['isbn'];?></td>
                                        <td><?=$items['title'];?></td>
                                        <td><?=$items['author'];?></td>
                                    </tr>
                                <?php
                            }
                        }else{
                            ?>
                            <td><?= "BOOK is Not Available!"; ?></td>
                            <?php
                        }
                        ?>
                    <?php
                    } else{

                    ?>
                        </tbody>
                    </table>

                <table id="datatablesSimple">
                    <thead>
                        <tr id="header">
                            <th>No</th>
                            <th>ISBN</th>
                            <th>Book Name</th>
                            <th>Author</th>
                            <th>Category</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="my-data" class="my-data">


                            
                            
                        <?php
                            // search button
                            $No = null;
                            $fetchBook = new bookFetch();
                            foreach($fetchBook->fetchData() as $data){
                        ?>
                        <tr>
                            <td><?=++$No;?></td>
                            <td><?=$data['isbn'];?></td>
                            <td><?=$data['title'];?></td>
                            <td><?=$data['author'];?></td>
                            <td><?=$data['category_name'];?></td>
                            <td><a href="./include/delete.inc.php?books_id=<?=$data['isbn'];?>"> <i class="fa-solid fa-trash-arrow-up fa-xl"></i> </a></td>

                        </tr>
                    

                        <?php
                        }
                            }
                        ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    <?php include('footer.php');?>
</body>
</html>