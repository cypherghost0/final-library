<?php

if(isset($_POST["add_student"]))
{
    $scid = $_POST['scid'];
    $fname = $_POST['f_name'];
    $lname = $_POST['l_name'];
    $stu_room = $_POST['stu_room'];

    include "../classes/module.class.php";

    $category = new studentSetUp($scid,$fname,$lname,$stu_room);
    $category->setUp();
    // header("location: ../index.php?error=none");
}