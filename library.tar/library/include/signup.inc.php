<?php

if(isset($_POST["sign_up"]))
{
    $username = $_POST['names'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    include "../classes/module.class.php";

    $signup = new mainController($username,$email,$password,$password2);
    $signup->signupUser();
    header("location: ../index.php?error=none");
}