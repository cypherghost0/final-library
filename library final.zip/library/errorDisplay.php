<?php
$errors = "";

if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case "emptyinput":
            $errors = "<div class='error'><span>Please fill empty fields</span></div>";
            break;
        case "Username":
            $errors = "<div class='error'><span>Invalid Username</span></div>";
            break;
        case "email":
            $errors = "<div class 'error'><span>Please use correct Email</span></div>";
            break;
        case "pwdMatch":
            $errors = "<div class='error'><span>Password doesn't match</span></div>";
            break;
        case "uidTakenCheck":
            $errors = "<div class='error'><span>Username or Email already exist</span></div>";
            break;
        case "Incorrect":
            $errors = "<div class='error'><span>Incorrect Username or Password</span></div>";
            break;
        case "bookborrowed":
            $errors = "<div class='error'><span>Book borrowed</span></div>";
            break;
        case "booksciderror":
            $errors = "<div class='error'><span>Please use accurate information</span></div>";
            break;
        default:
            $errors = "<div class='error'><span>Unknown error</span></div>";
            break;
    }
}
?>
