<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Borrow | Library</title>
    <style>
        .error {
            background-color: #ff4583;
            color: white;
            padding: 1rem;
            margin-top: 1rem;
            border-radius: .3rem;
        }
    </style>
</head>

<body>
    <?php include('navbar.php'); ?>
    <div class="body-content">
        <div class="sept left">
            <form method="POST" action="./include/borrow.inc.php" class="books">
                <div class="form-head">
                    <h2>Borrow book</h2>
                </div>
                <div class="ins">
                    <input type="text" placeholder="Student Card Id" name="scid">
                </div>
                <div class="ins">
                    <input type="text" placeholder="Book No(isbn)" name="isbn">
                </div>
                <button type="submit" class="btn btn-success" name="add_borrow"><i class="fa-solid fa-plus fa-xl"></i> Add book</button>
                <?php include('errorDisplay.php'); ?>
            </form>
        </div>
        <div class="sept right">
            <div class="content-header">
                <h2>Books Borrowed</h2>
                <div class="btn">
                    <a href="include/borrow.report.inc.php"><i class="fa-solid fa-download fa-xl"></i> Export</a>
                </div>
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                    <tr id="header">
                            <th>No</th>
                            <th>ISBN No.</th>
                            <th>Book Name</th>
                            <th>Student Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="my-data">
                        <?php
                        $No = null;
                        include('./classes/module.class.php');
                        $fetch = new borrowFetch();
                        $result = $fetch->fetchData();
                        foreach ($result as $data) {
                        ?>
                            <tr>
                                <td><?= ++$No; ?></td>
                                <td><?= $data['isbn']; ?></td>
                                <td><?= $data['title']; ?></td>
                                <td><?= $data['fname']; ?> <?= $data['lname']; ?></td>
                                <td><a href="./include/delete.inc.php?book_borrow_id=<?=$data['isbn']; ?>"><i class="fa-solid fa-arrow-rotate-left fa-xl"></i> Set returned</a></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>
    <?php include('footer.php');?>
</body>

</html>