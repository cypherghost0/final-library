<?php
include("../classes/module.class.php");

if(isset($_GET['category_id'])){
    $id = $_GET['category_id'];
    $deleteCategory = new categoryDestroy($id);
    $result = $deleteCategory->deleteData();
    if($result == true){
        header("location: ../Category.php");
    }
}

if(isset($_GET['student_id'])){
    $id = $_GET['student_id'];
    $deletestudent = new studentDestroy($id);
    $result = $deletestudent->deleteData();
    if($result == true){
        header("location: ../Student.php");
    }
}

if(isset($_GET['book_borrow_id'])){
    $id = $_GET['book_borrow_id'];
    $deletestudent = new borrowDestroy($id);
    $result = $deletestudent->deleteData();
    if($result == true){
        header("location: ../Student.php");
    }
}

if(isset($_GET['books_id'])){
    $id = $_GET['books_id'];
    $deletebook = new bookDistroy($id);
    $result = $deletebook->deleteData();
    if($result == true){
        header("location: ../Dashboard.php");
    }
}

if(isset($_GET['book_issue_id'])){
    $id = $_GET['book_issue_id'];
    $deleteissue = new issueDestroy($id);
    $result = $deleteissue->deleteData();
    if($result == true){
        header("location: ../Issued.php");
    }
}
if (isset($_GET['room_id'])) {
    $id = $_GET['room_id'];
    $deleteRoom = new roomDestroy($id); // Corrected class name
    $result = $deleteRoom->deleteData();
    if ($result == true) {
        header("location: ../Category.php");
    }
}